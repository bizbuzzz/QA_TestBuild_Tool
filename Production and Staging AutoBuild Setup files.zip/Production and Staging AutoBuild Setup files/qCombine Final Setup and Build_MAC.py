
import sys
import subprocess
from subprocess import Popen , PIPE
from tkinter import filedialog
import os
import fnmatch
from shutil import copyfile

import fileinput
import shutil
import urllib.request
import shutil
from shutil import copyfile


def generate_Signed_APK(option):
    paths = os.getcwd()

    if option == 1:
        storePassword = "\'B$Uwqtp9zr~zTeSt\'"
        keyAlias = "\'Testbedkey\'"
        keyPassword = "\'B$Uwqtp9zr~zTeSt\'"
        Folder = 'Staging'
        jks = "testbed-release-keystore"
    elif option == 2:
        storePassword = "\'DEV Not Updated\'"
        keyAlias = "\'DEV Not Updated\'"
        keyPassword = "\'DEV Not Updated\'"
        Folder = 'Development'
        jks = ""
    elif option == 3:
        storePassword = "\'B$Uwqtp9zr(~)z\'"
        keyAlias = "\'uploadkey\'"
        keyPassword = "\'B$Uwqtp9zr(~)z\'"
        Folder = 'Production'
        jks = "bizbuzzz_uploadkey"
    # folder_name = filedialog.askdirectory()

    with open('LOGGER.log', 'wb') as f:
        process1 = subprocess.Popen([r"./gradlew", "clean"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in iter(process1.stdout.readline, b''):  # replace '' with b'' for Python 3
            sys.stdout.write(str(line) + "\n")
            f.write(line)
        process = subprocess.Popen([r"./gradlew", "assembleRelease"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in iter(process.stdout.readline, b''):  # replace '' with b'' for Python 3
            sys.stdout.write(str(line) + "\n")
            f.write(line)

        for root, dirs, files in os.walk(paths):
            for file in files:
                if file == "app-release-unsigned.apk":
                    if "/app/" in root:
                        apk = os.path.join(root, file)
                        apkpath = root
                        print(file + " Found at " + root)
                        if os.path.isfile(paths + '/' + Folder + '/app-release-unsigned.apk'):
                            os.remove(paths + '/' + Folder + '/app-release-unsigned.apk')
                        copyfile(apk, paths + '/' + Folder + '/app-release-unsigned.apk')
                elif fnmatch.fnmatch(file, jks):
                    print(file + " Found at " + root)
                    jks = os.path.join(root, file)
                    jkspath = root
                    apks = paths + '/'+Folder+'/app-release-unsigned.apk'
                    jarsign = 'jarsigner -verbose -keystore ' + jks + ' -storepass ' + storePassword + ' -keypass ' + keyPassword + ' ' + apks + ' ' + keyAlias
                    folders = os.path.basename(paths)
                    signedapk = folders.replace('bizBuzzzNewUXUI-', '')
                    zipalign = r'zipalign -v 4 ' + apks + ' ' + paths + '/'+Folder+'/' + signedapk + '.apk'

        print("========================================JARSIGN===========================================")
        process1 = subprocess.Popen(jarsign, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
        for line in iter(process1.stdout.readline, b''):
            sys.stdout.write(str(line) + "\n")
            f.write(line)

        # Place zipalign in Android/SDk/build tools and set Path for it in ~/.bash_profile; Restart You Mac
        print("========================================Zipalign===========================================")
        process2 = subprocess.Popen(zipalign, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
        for line in iter(process2.stdout.readline, b''):
            sys.stdout.write(str(line) + "\n")
            f.write(line)

    print('Task Completed! Signed APK is in '+Folder+' Folder')


# !/usr/bin/env python3
# Please place this file inside required project

def setup_for_Build(option):
    Path = os.getcwd()
    count = 0

    if option == 1:
        Folder = 'Testfile'
        for pfile in os.walk(Path):
            for i in pfile[2]:
                if i == 'AndroidManifest.xml':
                    if "/app/src" in pfile[0]:
                        with fileinput.FileInput(pfile[0] + "/AndroidManifest.xml", inplace=True) as file:
                            for line in file:
                                if "For production Build" in line:
                                    print(line, end='')
                                else:
                                    print(line.replace("\"AIzaSyAfjRvAYEoosdOioNz_VJli7UrYSbpvlic\"",
                                                       "\"AIzaSyBTa01FnkrkCjybY0ViNBP2sUUaqwY9yQw\""), end='')
                        print("FoundFile at:" + pfile[0] + "/AndroidManifest.xml")
                elif i == 'BizBuzzzConstants.java':
                    if "/app/src" in pfile[0]:
                        with fileinput.FileInput(pfile[0] + '/BizBuzzzConstants.java', inplace=True) as file:
                            for line in file:
                                if "For production Build" in line:
                                    print(line, end='')
                                elif "liveDatabase/liveDatabase" in line:
                                    print(line.replace("\"liveDatabase/liveDatabase\"", "\"AppStaging/liveDatabase\""),
                                          end='')
                                elif "qa_5july" in line:
                                    print(line.replace("\"qa_5july\"", "\"AppStaging/liveDatabase\""),
                                          end='')
                                else:
                                    print(line.replace("\"liveDatabase\"", "\"AppStaging/liveDatabase\""), end='')
                        print("FoundFile at:" + pfile[0] + "/BizBuzzzConstants.java")
                elif i == 'logback.xml':
                    if "/app/src" in pfile[0]:
                        with fileinput.FileInput(pfile[0] + '/logback.xml', inplace=True) as file:
                            for line in file:
                                if "For production Build" in line:
                                    print(line, end='')
                                elif "LICENSE" in line:
                                    print(line, end='')
                                elif "Create" in line:
                                    print(line, end='')
                                elif "ERROR" in line:
                                    print(line.replace("\"ERROR\"", "\"DEBUG\""), end='')
                                elif "<!--" in line:
                                    print(line.replace("<!--", " ").replace("-->", " "), end='')
                                else:
                                    print(line, end='')
                        print("FoundFile at:" + pfile[0] + "/logback.xml")

                # elif pfile == 'proguard-rules.pro':
                #     with fileinput.FileInput('proguard-rules.pro', inplace=True) as file:
                #         for line in file:
                #             print(line.replace("\"AIzaSyDg0n-_93lzmSCiDx0DG8gUlRa0pZD5JwM\"",
                #                                "\"AIzaSyBTa01FnkrkCjybY0ViNBP2sUUaqwY9yQw\""), end='')
                elif i == 'remote_config_defaults.xml':
                    if "/app/src" in pfile[0]:
                        with fileinput.FileInput(pfile[0] + '/remote_config_defaults.xml', inplace=True) as file:
                            for line in file:
                                if "dev" in line:
                                    print(line, end='')
                                else:
                                    print(line.replace("e5krp",
                                                       "qmkk3"), end='')
                        print("FoundFile at:" + pfile[0] + "/remote_config_defaults.xml")

                elif i == 'RestHelper.java':
                    if "/app/src" in pfile[0]:
                        with fileinput.FileInput(pfile[0] + '/RestHelper.java', inplace=True) as file:
                            for line in file:
                                if "For production Build" in line:
                                    print(line, end='')
                                elif "https://production-dot-bizbuzzz-live-db.appspot.com" in line:
                                    print(line.replace("\"https://production-dot-bizbuzzz-live-db.appspot.com\"",
                                                       "\"bizbuzzztestbed-8ba40.appspot.com/o/AppStaging/liveDatabase\""),
                                          end='')
                                elif "https://bizbuzzzdevbed-4e5c6.appspot.com" in line:
                                    print(line.replace("\"https://bizbuzzzdevbed-4e5c6.appspot.com\"",
                                                       "\"bizbuzzztestbed-8ba40.appspot.com/o/AppStaging/liveDatabase\""),
                                          end='')
                                else:
                                    print(line.replace("\"https://qaserver-dot-bizbuzzztestbed-8ba40.appspot.com\"",
                                                       "\"bizbuzzztestbed-8ba40.appspot.com/o/AppStaging/liveDatabase\""),
                                          end='')
                        print("FoundFile at:" + pfile[0] + "/RestHelper.java")

                elif i == 'google-services.json':
                    if os.getcwd()+"/app" in pfile[0]:
                        shutil.copy(os.getcwd() + '/' + Folder + "/google-services.json",
                                 pfile[0] + "/google-services.json")
                        print("FoundFile at:" + pfile[0] + "/google-services.json")
                else:
                    count = count + 1

    elif option == 2:
        Folder = 'Development'
    elif option == 3:
        Folder = 'Production'

        for pfile in os.walk(Path):
            for i in pfile[2]:
                if i == 'AndroidManifest.xml':
                    if "/app/src" in pfile[0]:
                        copyfile(os.getcwd() + '/' + Folder + "/AndroidManifest.xml", pfile[0] + "/AndroidManifest.xml")
                        print("FoundFile at:" + pfile[0] + "/AndroidManifest.xml")
                elif i == 'BizBuzzzConstants.java':
                    if "/app/src" in pfile[0]:
                        copyfile(os.getcwd() + '/' + Folder + "/BizBuzzzConstants.java",
                                 pfile[0] + "/BizBuzzzConstants.java")
                        print("FoundFile at:" + pfile[0] + "/BizBuzzzConstants.java")
                elif i == 'logback.xml':
                    if "/app/src" in pfile[0]:
                        copyfile(os.getcwd() + '/' + Folder + "/logback.xml", pfile[0] + "/logback.xml")
                        print("FoundFile at:" + pfile[0] + "/logback.xml")
                elif i == 'remote_config_defaults.xml':
                    if "/app/src" in pfile[0]:
                        copyfile(os.getcwd() + '/' + Folder + "/remote_config_defaults.xml",
                                 pfile[0] + "/remote_config_defaults.xml")
                        print("FoundFile at:" + pfile[0] + "/remote_config_defaults.xml")
                elif i == 'RestHelper.java':
                    if "/app/src" in pfile[0]:
                        copyfile(os.getcwd() + '/' + Folder + "/RestHelper.java", pfile[0] + "/RestHelper.java")
                        print("FoundFile at:" + pfile[0] + "/RestHelper.java")
                elif i == 'google-services.json':
                    if os.getcwd()+"/app" in pfile[0]:
                        os.remove(pfile[0] + "/google-services.json")
                        shutil.copyfile(os.getcwd() + '/' + Folder + "/google-services.json", pfile[0] + "/google-services.json")
                        print("FoundFile at:" + pfile[0] + "/google-services.json")
                else:
                    count = count + 1

    input('Setup for Build Task Completed!')
    main()


def main():
    print("\nWhere You want to Build the App\n")
    input1 = int(input("\n1.) On Staging\n2.) On Development\n3.) On Production \n4.) EXIT\n\n"))
    if input1 in range(1, 4):
        print("=======================================================================================================")
        input2 = input("Choose Your Option:\n1.)Setup_for_Build\n2.)Generate_Signed_APK\n")

        if input2 == '1':
            setup_for_Build(input1)
        elif input2 == '2':
            generate_Signed_APK(input1)
        else:
            print("Wrong Option")
            main()
    else:
        exit()


if __name__ == '__main__':
    main()



