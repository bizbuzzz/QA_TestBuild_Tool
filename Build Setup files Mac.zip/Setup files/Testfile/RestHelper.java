package com.bizbuzzz.restservice;

import com.bizbuzzz.bizmanagement.bizteam.models.BizTeam;
import com.bizbuzzz.bizmanagement.models.BizTeamInvitation;
import com.bizbuzzz.bizmanagement.models.BizTeamRemovalRequest;
import com.bizbuzzz.models.OTPWrapper;
import com.bizbuzzz.models.UserAuthData;
import com.bizbuzzz.ordermanagement.models.CustomerResponseForPriceCheckConfirmation;
import com.bizbuzzz.ordermanagement.models.NotifyPriceChange;
import com.bizbuzzz.ordermanagement.models.OrderDetails;
import com.bizbuzzz.ordermanagement.models.OrderStatus;

import org.androidannotations.rest.spring.annotations.Body;
import org.androidannotations.rest.spring.annotations.Get;
import org.androidannotations.rest.spring.annotations.Path;
import org.androidannotations.rest.spring.annotations.Post;
import org.androidannotations.rest.spring.annotations.Rest;
import org.androidannotations.rest.spring.api.RestClientErrorHandling;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

/**
 * Created by sanjivankumar on 4/11/18.
 */
@Rest(rootUrl = "https://qaserver-dot-bizbuzzztestbed-8ba40.appspot.com",
      converters = {MappingJackson2HttpMessageConverter.class,
                    StringHttpMessageConverter.class},
      interceptors = {RequestInterceptor.class},
      responseErrorHandler = RestServiceResponseErrorHandler.class)
public interface RestHelper
        extends RestClientErrorHandling{
    @Post("/biz_team/admin_response_for_removal_req/{isAccepted}")
    Response adminResponseForBizTeamRemovalReq(
            @Path
                    boolean isAccepted,
            @Body
                    BizTeamRemovalRequest bizTeamRemovalRequest);

    @Get("/commons/get_timestamp_in_sec_for_loc")
    Response getTimeStampInMilliSecForLocation();

    @Post("/biz_team/invite_user_to_join")
    Response inviteUserToJoinBizTeam(
            @Body
                    BizTeamInvitation bizTeamInvitation);

    @Post("/order_mgmt/notify_customer_response_for_price_change/{customerResponseForPriceCheckConfirmation}")
    Response notifyCustomerResponseForPriceChange(
            @Path
                    CustomerResponseForPriceCheckConfirmation customerResponseForPriceCheckConfirmation,
            @Body
                    OrderDetails orderDetails);

    @Post("/order_mgmt/notify_price_change")
    Response notifyPriceChange(
            @Body
                    NotifyPriceChange notifyPriceChange);

    @Post("/biz_team/invitation_expired/{teamMemberFirebaseUid}")
    public Response onBizTeamInvitationExpired(
            @Path
                    String teamMemberFirebaseUid,
            @Body
                    BizTeam bizTeam);

    @Post("/biz_team/team_member_removal_request_expired/{teamMemberFirebaseUid}")
    Response onBizTeamRemovalRequestExpired(
            @Path
                    String teamMemberFirebaseUid,
            @Body
                    BizTeam bizTeam);

    @Post("/order_mgmt/order_cancelled")
    Response orderCancelled(
            @Body
                    OrderDetails orderDetails);

    @Post("/order_mgmt/order_completed")
    Response orderCompleted(
            @Body
                    OrderDetails orderDetails);

    @Post("/order_mgmt/order_processed")
    Response orderProcessed(
            @Body
                    OrderDetails orderDetails);

    @Post("/order_mgmt/place_new_order")
    Response placeNewOrder(
            @Body
                    OrderDetails orderDetails);

    @Post("/biz_team/removal_req")
    Response removalReqFromBizTeam(
            @Body
                    BizTeamRemovalRequest bizTeamRemovalRequest);

    @Post("/biz_team/remove_team_member/{teamMemberFirebaseUid}")
    Response removeTeamMember(
            @Path
                    String teamMemberFirebaseUid,
            @Body
                    BizTeam bizTeam);

    @Post("/commons/search_item_in_bizofferings/{bizID}/{textToSearch}")
    Response searchItemsInBizOfferings(
            @Path
                    String bizID,
            @Path
                    String textToSearch);

    @Post("/commons/send_otp")
    Response sendOTP(
            @Body
                    OTPWrapper data);

    /**
     * Method to set header
     *
     * @param name
     * @param value
     */
    void setHeader(String name, String value);

    @Post("/order_mgmt//update_order_status/{orderStatus}")
    Response updateOrderStatus(
            @Path
                    OrderStatus orderStatus,
            @Body
                    OrderDetails orderDetails);

    @Post("/biz_team/update_team_member/{teamMemberFirebaseUid}")
    Response updateTeamMember(
            @Path
                    String teamMemberFirebaseUid,
            @Body
                    BizTeam bizTeam);

    @Post("/commons/update_user")
    Response updateUser(
            @Body
                    UserAuthData userAuthData);

    @Post("/biz_team/user_response_for_invitation/{isAccepted}")
    Response userResponseForBizTeamInvitation(
            @Path
                    boolean isAccepted,
            @Body
                    BizTeamInvitation bizTeamInvitation);

    @Get("/commons/get_customer_cah_back_info/{customerId}")
    Response get_customer_cah_back_info(
            @Path
                    String customerId);

    @Get("/commons/get_customer_cash_back_orders_for_biz/{bizId}/{customerId}")
    Response get_customer_cash_back_orders_for_biz(
            @Path
                    String bizId,
            @Path
                    String customerId);

    @Get("/commons/get_biz_cah_back_info/{bizId}")
    Response get_biz_cah_back_info(
            @Path
                    String bizId);

    @Get("/commons/get_biz_cah_back_orders_for_customer/{customerId}/{bizId}")
    Response get_biz_cah_back_orders_for_customer(
            @Path
                    String customerId,
            @Path
                    String bizId);

    @Post("/order_mgmt/process_cash_back_on_order")
    Response process_cash_back_on_order(
            @Body
                    OrderDetails orderDetails);

    @Post("/commons/verify_otp")
    Response verifyOTP(
            @Body
                    OTPWrapper data);
}


