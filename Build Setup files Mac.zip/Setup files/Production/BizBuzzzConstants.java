
/*
 *  See the file "LICENSE" for the full license governing this code.
 */
package com.bizbuzzz.app;

/**
 * Created by sanjivan_kumar on 2/3/16.
 */
public class BizBuzzzConstants{
    public static final String ACCESS_RIGHTS = "accessRights";

    public static final String APP_INTRO_DONE = "appIntroDone";

    public static final String BIZ_ACCOUNT = "bizAccount";

    public static final String BIZ_ACCOUNT_PREVIOUS = "bizAccountPrevious";

    public static final String BIZ_ACCOUNT_UPDATE_FROM_BACK_END = "bizAccountUpdateFromBackEnd";

    public static final String BIZ_BLOCKED = "bizBlocked";

    public static final String BIZ_BUZZZ_DATA_BASE_VERSION = "liveDatabase";

    public static final String BIZ_BUZZZ_DATA_BASE_VERSION_FOR_COUNTRY = "v1_0";

    public static final String BIZ_BUZZZ_STORAGE_VERSION = "liveDatabase";

    public static final String BIZ_BUZZZ_STORAGE_VERSION_FOR_COUNTRY = "v1_0";

    public static final String BIZ_CARD_MAP = "bizCardMap";

    public static final String BIZ_CARD_MAP_PREVIOUS = "bizCardMapPrevious";

    public static final String BIZ_CARD_MAP_UPDATE_FROM_BACKEND = "bizCardMapUpdateFromBackEnd";

    public static final String BIZ_CART_MAP = "bizCartMap";

    public static final String BIZ_CART_MAP_FOR_ORDER_PROCESSING = "bizCartMapForOrderProcessing";

    public static final String BIZ_CATEGORY_TITLE = "bizCategoryTitle";

    public static final String BIZ_FAVOURITE = "bizFavourite";

    public static final String BIZ_FAVOURITE_OR_BLOCK = "bizFavouriteOrBlock";

    public static final String BIZ_INFO = "bizInfo";

    public static final String BIZ_INFO_MAP = "bizInfoMap";

    public static final String BIZ_INFO_PREVIOUS = "bizInfoPrevious";

    public static final String BIZ_INFO_UPDATE_FROM_BACKEND = "bizInfoUpdateFromBackEnd";

    public static final String BIZ_MANAGEMENT_OPTIONS = "bizManagementOptions";

    public static final String BIZ_MANAGEMENT_OPTIONS_FOR_TEAM_MEMBERS =
            "bizManagementOptionsForTeamMembers";

    public static final String BIZ_OFFERINGS_MAP_TYPE_DURING_CHOOSE_TEMPLATE =
            "bizOfferingsMapTypeDuringChooseTemplate";

    public static final String BIZ_OFFERINGS_TYPE_THREE_PHOTOS_PATH_ON_STORAGE =
            "bizOfferingsTypeThreePhotos";

    public static final String BIZ_OFFERINGS_TYPE_TWO_PHOTOS_PATH_ON_STORAGE =
            "bizOfferingsTypeTwoPhotos";

    public static final String BIZ_OR_USER = "bizOrUser";

    public static final String BIZ_PHOTOS_PATH_ON_STORAGE = "bizPhotos";

    public static final String BIZ_SUB_CATEGORY_TITLE = "bizSubCategoryTitle";

    public static final String BIZ_SUB_CATEGORY_TITLE_SAMPLE_PAGE = "bizSubCategoryTitleSamplePage";

    public static final String BIZ_TEAM_INVITAION_MAP = "bizTeamInvitaionMap";

    public static final String BIZ_UNDER_MY_REGION_OBJECT_JSON = "bizUnderMyRegionObjectJson";

    public static final String BIZ_UPDATE_FROM_BACK_END = "bizUpdateFromBackEnd";

    public static final String BUZZZ_BLOCKED = "buzzzBlocked";

    public static final String BUZZZ_IMAGES_PATH_ON_STORAGE = "buzzzImages";

    public static final String COUNTRY_NAME = "countryName";

    public static final String COUNTRY_NAME_CODE = "countryNameCode";

    public static final String COUNTRY_PHONE_NUMBER_CODE = "countryPhoneNumberCode";

    public static final String CUSTOMER_PAGE_CREATION_REQ_INFO = "customerPageCreationReqInfo";

    public static final String FIREBASE_USER_ID = "firebaseUserId";

    public static final String IS_BIZ_UPDATE_FROM_BACK_END = "isBizUpdateFromBackEnd";

    public static final String IS_FIRST_RUN_FOR_BIZ_USER = "IS_FIRST_RUN_FOR_BIZ_USER";

    public static final String IS_REGISTRATION_COMPLETED = "isRegistrationCompleted";

    public static final String IS_USER_BIZ_OWNER_OR_REPRESENTATIVE =
            "isUserBizOwnerOrRepresentative";

    public static final String LOCATION = "location";

    public static final String MAIN_BIZ_IMAGE_PATH_ON_STORAGE = "mainBizImage";

    public static final String MESSAGING_INFO = "messagingInfo";

    public static final String OTP_SESSION_ID = "otpSessionId";

    public static final String PHONE_NUMBER = "phoneNumber";

    public static final String REGISTRATION_STATE = "registrationState";

    public static final int SMS_CODE_AUTO_RETRIEVAL_TIMEOUT = 4002;

    public static final int SMS_CODE_AUTO_VERIFIED = 4003;

    public static final int SMS_CODE_REQUESTED = 4000;

    public static final String SMS_CODE_RESPONSE_DATA = "smsCodeResponseData";

    public static final String SMS_CODE_RETRIES_DONE = "smsCodeRetriesDone";

    public static final int SMS_CODE_SENT = 4001;

    public static final String SMS_CODE_TIME_STAMP = "SMS_CODE_TIME_STAMP";

    public static final String SMS_CODE_VERIFICATION_DATA = "smsCodeVerificationData";

    public static final int SMS_CODE_VERIFICATION_FAILED = 1000;

    public static final int SMS_CODE_VERIFICATION_FAILURE_API_NOT_AVAILABLE = 1004;

    public static final int SMS_CODE_VERIFICATION_FAILURE_INVALID_CREDENTIALS = 1001;

    public static final int SMS_CODE_VERIFICATION_FAILURE_PROJECT_CONFIG_INCORRECT = 1003;

    public static final int SMS_CODE_VERIFICATION_FAILURE_QUOTA_EXCEEDED = 1002;

    public static final String STATE_USER_PROFILE_FRAGMENT = "stateUserProfileFragment";

    public static final String TODAYS_UPDATE_DATE = "todaysUpdateDate";

    public static final String UPDATE_FOR_TODAY_PHOTOS_PATH_ON_STORAGE = "updateForTodayPhotos";

    public static final String URI_SCHEME_FILE = "file";

    public static final String URI_SCHEME_HTTP = "http";

    public static final String URI_SCHEME_HTTPS = "https";

    public static final String USER = "user";

    public static final String USER_ID_IMAGE_PATH_ON_STORAGE = "userId";

    public static final String USER_PROFILE_CREATION_STATUS = "userProfileCreationStatus";

    public static final String USER_PROFILE_IMAGE_PATH_ON_STORAGE = "userProile";
}
